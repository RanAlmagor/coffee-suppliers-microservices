# 📘 Step-by-Step Installation Guide – AWS Microservices & CI/CD Lab

Welcome! This guide will walk you through every single step of the lab: **“Building Microservices and a CI/CD Pipeline with AWS”** — even if you've never used AWS before. Every action is explained clearly, so just follow along.

---

## 📋 Table of Contents
1. [Lab Goal – What Are We Building?](#lab-goal--what-are-we-building)
2. [What You’ll Need](#what-youll-need)
3. [Logging into the Lab Environment](#logging-into-the-lab-environment)
4. [Phase 1 – Planning & Architecture](#phase-1--planning--architecture)
5. [Phase 2 – Reviewing the Existing App](#phase-2--reviewing-the-existing-app)
6. [Phase 3 – Setup Your Development Environment](#phase-3--setup-your-development-environment)
7. [Phase 4 – Create Docker Containers](#phase-4--create-docker-containers)
8. [Phase 5 – Deploy with AWS ECS (Fargate)](#phase-5--deploy-with-aws-ecs-fargate)
9. [Phase 6 – Build the CI/CD Pipeline](#phase-6--build-the-cicd-pipeline)
10. [Phase 7 – Final Testing & Screenshots](#phase-7--final-testing--screenshots)

---

## 🎯 Lab Goal – What Are We Building?

You’ll take an old-school Java web app (a single file, one big block) and turn it into **two microservices**:
- `customer-service`
- `employee-service`

Then, you’ll:
- 📦 Package them with Docker
- 🚀 Deploy them to AWS ECS (Fargate)
- 🔄 Automate everything using a CI/CD pipeline (CodeCommit → CodeBuild → CodeDeploy)

---

## 🧰 What You’ll Need

✔️ AWS Academy access  
✔️ Internet connection  
✔️ Your AWS Lab credentials (provided by your instructor)

---

## 🔐 Logging into the Lab Environment

1. Go to [AWS Academy Student Portal](https://awsacademy.instructure.com/)
2. Click on the lab named **“Microservices and CI/CD”**
3. Click `Start Lab` (wait ~1 min)
4. Click `AWS Console` > then `Open AWS Console`
5. You’re now inside the AWS sandbox (aka safe playground)

---

## 📐 Phase 1 – Planning & Architecture

### 🖼️ Task 1.1 – Draw Your System
- Open [draw.io](https://app.diagrams.net/)
- Create this structure:
  - Internet → **ALB** (Application Load Balancer)
  - ALB → **Target Groups** → **ECS Services** (customer & employee)
  - Each service uses a **Docker container**
  - Add **CodeCommit**, **CodeBuild**, and **CodeDeploy** connected to CodePipeline
- Export your diagram as PNG/JPEG

### 💵 Task 1.2 – Estimate Cost
- Open [AWS Pricing Calculator](https://calculator.aws.amazon.com/)
- Add:
  - 2x Fargate tasks (~0.5 vCPU, 1GB RAM)
  - ALB (100k requests/month)
  - CodeBuild & CodePipeline (minimal usage)
- Save or screenshot your estimate

---

## 🔍 Phase 2 – Reviewing the Existing App

### Task 2.1 – Open the Monolithic App
- Instructor will provide a link (e.g., `http://ec2-...`)
- Open it in your browser, explore pages

### Task 2.2 – Understand the Code
- You’ll receive a `.zip` or Git repo with the Java project
- Inside you’ll see a big file mixing customer + employee logic

---

## 💻 Phase 3 – Setup Your Development Environment

### Task 3.1 – Launch AWS Cloud9
1. Go to AWS Console → search `Cloud9`
2. Click “Create environment”
3. Name it: `microservices-dev`
4. Instance type: `t3.micro`
5. Region: `us-east-1`
6. Click Create and wait

### Task 3.2 – Load the Code
- Run this in Cloud9 Terminal:
```bash
wget https://example.com/app.zip
unzip app.zip
cd app
```

### Task 3.3 – Create Service Folders
```bash
mkdir customer-service employee-service
mv src/com/company/customer customer-service/
mv src/com/company/employee employee-service/
```

---

## 🐳 Phase 4 – Create Docker Containers

### Dockerfile (example):
Inside each folder, create a file named `Dockerfile`:

```Dockerfile
FROM openjdk:8
COPY . /app
WORKDIR /app
RUN javac Main.java
CMD ["java", "Main"]
```

### Build and Run:
```bash
docker build -t customer-service .
docker run -p 8080:8080 customer-service
```

Check at `http://localhost:8080`

---

## 🛰️ Phase 5 – Deploy with AWS ECS (Fargate)

### Step-by-Step:
1. Go to ECS → “Create Cluster” → Fargate → Cluster name: `microservices-cluster`
2. Create Task Definitions for each service
3. Define:
   - Container name
   - Image URL (from ECR)
   - Memory/CPU
   - Port mappings
4. Create Service for each one
5. Attach to the Application Load Balancer

---

## 🔁 Phase 6 – Build the CI/CD Pipeline

### CodeCommit:
- Go to CodeCommit → Create new repos:
  - `customer-service-repo`
  - `employee-service-repo`
- Push your code:
```bash
git init
git remote add origin https://git-codecommit...
git add .
git commit -m "initial"
git push -u origin main
```

### CodeBuild:
- Create two CodeBuild projects
- Use `buildspec.yml` like:
```yaml
version: 0.2
phases:
  build:
    commands:
      - docker build -t $IMAGE .
      - docker tag $IMAGE:latest $ECR_URI
      - docker push $ECR_URI
```

### CodePipeline:
- Create pipelines:
  - Source: CodeCommit
  - Build: CodeBuild
  - Deploy: ECS (Blue/Green)

---

## 📸 Phase 7 – Final Testing & Screenshots

1. Visit ALB DNS URL → `/customers` and `/employees` must work
2. Check:
   - Services are healthy
   - Tasks are running
   - Pipeline succeeded
3. Take screenshots of:
   - Architecture diagram
   - ECS services
   - Pipeline status
   - Running containers

---

🎉 Done! You’ve built, deployed, and automated modern microservices using AWS. Well done!
